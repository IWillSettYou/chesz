import {Piece} from "./Piece"
class Chess {
    player!: boolean;


}
